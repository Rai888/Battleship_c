﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship_c
{
    public class Coordinates
    {
        public string Bottone { get; set; }
        public int Lunghezza { get; set; }

        public Coordinates(string bottone, int lunghezza)
        {
            Bottone = bottone;
            Lunghezza = lunghezza;
        }
    }
}
