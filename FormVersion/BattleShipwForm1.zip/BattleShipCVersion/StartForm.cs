﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BattleShipCVersion
{
    public partial class StartForm : Form
    {
        public StartForm()
        {
            InitializeComponent();
        }

        private void StartForm_Load(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            LoginForm f2 = new LoginForm();
            f2.Show(); //mostra il form per il login
            this.Hide();//nasconde il form di avvio programma
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); //chiude l'applicazione
        }

        private void StartForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();//se chiudi la finestri termini l'applicazione
        }
    }
}
