﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        int lunghezza = 0;
        partitaPeer partita;
        public Window2(peer peer, int turno)
        {
            InitializeComponent();

            partita = new partitaPeer(peer, turno);
        }

        private void hit1(object sender, RoutedEventArgs e)
        {
            string btnName = "";


            btnName = (sender as Button).Name;

            if (radioVerticale.IsChecked == true)
            {
                inserisciNaviVerticale(this, btnName, lunghezza);
            }
            else
                inserisciNaviOrizzontale(this, btnName, lunghezza);
        }

        private void btnCarrier_Click(object sender, RoutedEventArgs e)
        {
            lunghezza = 5;
        }

        private void btnBattleship_Click(object sender, RoutedEventArgs e)
        {
            lunghezza = 4;
        }

        private void btnDestroyer_Click(object sender, RoutedEventArgs e)
        {
            lunghezza = 3;
        }

        private void btnSubmarine_Click(object sender, RoutedEventArgs e)
        {
            lunghezza = 3;
        }

        private void btnPatrol_Click(object sender, RoutedEventArgs e)
        {
            lunghezza = 2;
        }


        public void inserisciNaviVerticale(Window2 window, string bottone, int lunghezza)//metodo aggiunge navi in verticale
        {
            if (int.Parse(bottone.Substring(1, 1)) + lunghezza <= 11)
            {

                Button b = (Button)window.FindName(bottone);//cerca il bottone sulla quale apportare le modifiche visive

                string temp = bottone; //in temp viene salvato il nome del bottone (es: A1,A2,E3,F4)

                string lettera = temp.Substring(0, 1);//salvo la lettera per poi andare ad incrementare solo il numero

                int n = 0;

                for (int i = 0; i < lunghezza; i++)
                {
                    partita.listNave.Add(temp);
                    b.Content = "XXX";//sulle celle selezionate aggiungo XXX
                    n = int.Parse(temp.Substring(1, 1));
                    n++;//incremento riga
                    temp = lettera + n.ToString();
                    b = (Button)window.FindName(temp);
                }
            }

        }

        public void inserisciNaviOrizzontale(Window2 window, string bottone, int lunghezza)//metodo aggiunge navi in orizzontale
        {
            if (char.Parse(bottone.Substring(0, 1)) + lunghezza <= 'K')
            {
                Button b = (Button)window.FindName(bottone);//cerca il bottone sulla quale apportare le modifiche visive

                string temp = bottone;//in temp viene salvato il nome del bottone (es: A1,A2,E3,F4)

                string numero = temp.Substring(1, bottone.Length - 1);//salvo il numero per poi andare ad incremetare la lettera

                char l = ' ';

                for (int i = 0; i < lunghezza; i++)
                {
                    partita.listNave.Add(temp);
                    b.Content = "XXX";//sulle celle selezionate aggiungo XXX
                    l = char.Parse(temp.Substring(0, 1));
                    l++;//incremento lettera
                    temp = l.ToString() + numero;
                    b = (Button)window.FindName(temp);
                }
            }

        }

        private void btnAvvia_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}

