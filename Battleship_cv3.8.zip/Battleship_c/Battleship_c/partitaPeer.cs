﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Battleship_c
{
    class partitaPeer
    {
        public peer peer;
        private List<string> listNave;
        public int turno;

        public partitaPeer(peer peer, int turno) {
            this.peer = peer;
            this.listNave = Random();
            this.turno = turno;
        }


        
        private List<string> Random()
        {  //per le navi 
            var n = new Random();
            byte[] j;
            int l1, n2;
            string temp = "";
            List<string> v = new List<string>();
            for (int i = 0; i < 25; i++)
            {
                l1 = n.Next(65, 74);
                j = BitConverter.GetBytes(l1);  //una lettera a random da A a J

                n2 = n.Next(1, 10);
                temp = (Encoding.ASCII.GetString(j) + n2.ToString()).Remove(1, 3);
                v.Add(temp);
            }
            return v;

        }


        public int ricercaNave(string s, Window1 window)
        {
            int ris=-1;
            //-1(mancato) / 0(colpito) / 1(affondato)
            for (int i = 0; i < listNave.Count; i++)
            {
                if (s == listNave.ElementAt(i))
                {
                    ris=0;
                    ris=affondato(window, s);
                }
            }
            return ris;
        }

        private int affondato(Window1 window, string s) {
            /*a     b   c   d   e
             1      x       
             2      x          
             3      x         
             4              x   x
             5              
             */
            //considerando un colpito  sicuro
            //se sulla colonna successiva o sul numero successivo ci sono altre x allora return 1, ovvero affondata
            int n = Int32.Parse(s.Substring(1, 2));//3

            //s=D3 
            char c = s[0];
            int ris;
            string destr = c + n.ToString();   //E3
            string gi = s[0] + (++n).ToString();//D4
            string sinistr = c + n.ToString();//C3
            string suu = s[0] + (--n).ToString();//D2
            bool sent;
            string str = "";
            int pos = 0;

            if (listNave.Contains(gi)) { str = gi; }
            else if (listNave.Contains(suu)) { str = suu; }
            else if (listNave.Contains(destr)) { str = destr; c = btnLettera(c, 0); pos = 1; }
            else if (listNave.Contains(sinistr)) { str = sinistr; c = btnLettera(c, 1); pos = 2; }
            //devo fissare la direzione

            Button b = (Button)window.FindName(str);

            do
            {
                if (listNave.Contains(str))
                {
                    if ((string)b.Content == "X")
                    {
                        sent = true;
                        ris = 1;
                        if (pos == 1) c = btnLettera(c, 0);
                        else if (pos == 2) c = btnLettera(c, 1);
                    }
                    else
                    {
                        sent = false;
                        ris = 0;
                    }
                }
                else {sent = false; ris = 1;}
            } while (sent);

            return ris;

        }

        private char btnLettera(char c, int i)
        {
            int letteraAscii = (int)c;//65 = a
            char letteraSuccessiva;
            if (i==0) letteraSuccessiva = (char)++letteraAscii;//c
            else
                letteraSuccessiva = (char)--letteraAscii;//a
            return letteraSuccessiva;
        }


    }
}
