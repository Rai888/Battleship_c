﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        /*
         UdpClient client = new UdpClient();

        byte[] data = Encoding.ASCII.GetBytes("CIAO SERVER");

        client.Send(data, data.Length, "localhost", 12345);



        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any, 0);

        byte[] dataReceived = client.Receive(ref riceveEP);

        String risposta=Encoding.ASCII.GetString(dataReceived);

        Console.WriteLine(risposta);
         */



        UdpClient client = new UdpClient(64444);
        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any,0);
        peer peer1 = new peer();// peer 1
        peer peer2 = new peer();//peer 2

        public MainWindow()
        {
            InitializeComponent();
        }

        

        private void inviaPacchetto() {
            if (!peer1.getConnesso())
            {
                byte[] data = Encoding.ASCII.GetBytes("NC;" + "localhost" + ";64444");    //richiesta di connessione NC=> Nuova Connessione    al posto di "localhost", peer2.getIndirizzoHost()
                client.Send(data, data.Length, "localhost", 64444);  //ci andrà l'indirizzo ip dell'altro peer
            }
            else
            {
                MessageBox.Show("Sei Già Connesso!");
            }
            
        }


        private void riceviPacchetto() {
            byte[] dataReceived = client.Receive(ref riceveEP);     //ricevo la richiesta di connessione
            String risposta = Encoding.ASCII.GetString(dataReceived);//elaboro la risposta
            string ipDestinatario= riceveEP.Address.ToString();      //prendo l'ip del destinatario |   potevo prenderlo dal secondo campo della risposta
            string portaDestinatario=riceveEP.Port.ToString();       //prendo la porta del destinatario |   potevo prenderla dal terzo campo della risposta
            string comando=risposta.Substring(0, 2);                 //prendo il comando    

            byte[] risp;

            if (comando=="NC")  //se il comando è una richiesta di connessione
            {
                if (!peer2.getConnesso())   //controllo che non sia connnesso il peer 
                {
                    txtPeer1.Text = "In corso...";
                    if (MessageBox.Show("Vuoi connetterti con l'Host?", "Seleziona", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
                    {
                        accettaRichiestaConnessione(ipDestinatario);    // mi passo l'ip del destinatario con cui instauro una connessione
                        risp = Encoding.ASCII.GetBytes("RC;true;" + ipDestinatario);          // pacchetto per il destinatario-accetta connessione      va messo al posto dell'ipDestinatario, l'ip del secondo peer
                        client.Send(risp, risp.Length, "localhost", 64444);
                    }
                    else
                    {
                        risp = Encoding.ASCII.GetBytes("RC;false;" + ipDestinatario);   //pacchetto per il destinatario-rifiuto connessione
                        client.Send(risp, risp.Length, "localhost", 64444);
                    }

                    confermaPeer2();
                }
                else
                {
                    MessageBox.Show("L'host è già connesso!");
                }
                /*
                if (!peer2.getConnesso())    //controllo che non sia connnesso il peer 
                {
                    txtPeer1.Text = "In corso...";
                    accettaRichiestaConnessione(ipDestinatario);    // mi passo l'ip del destinatario con cui instauro una connessione
                    risp = Encoding.ASCII.GetBytes("RC;true;" + ipDestinatario);          // pacchetto per il destinatario-accetta connessione      va messo al posto dell'ipDestinatario, l'ip del secondo peer
                    client.Send(risp, risp.Length, "localhost", 64444);
                }
                else {                                                              //se è gia connesso
                    risp = Encoding.ASCII.GetBytes("RC;false;" + ipDestinatario);   //pacchetto per il destinatario-rifiuto connessione
                    client.Send(risp, risp.Length, "localhost", 64444);
                }*/
                
            }
           
        }


        private void accettaRichiestaConnessione(string ipdest) {
            peer2.setConnesso(true);
            peer2.setIPDest(ipdest);
            /*
            peer1.setConnesso(true);
            peer1.setIPDest("localhost"); //peer1.setIPDest(peer2.getIndirizzoHost());
            txtPeer1.Text = "Connesso!";
            */
            txtPeer2.Text = "Connesso!";
        }


        private void confermaPeer2() {
            byte[] data = client.Receive(ref riceveEP);
            string ip=riceveEP.Address.ToString();
            string comando = Encoding.ASCII.GetString(data).Substring(0, 2);
            string porta=riceveEP.Port.ToString();
            string[] v=Encoding.ASCII.GetString(data).Split(';');



            if (v[0]== "RC")
            {
                if (v[1]=="true")
                {
                    peer1.setConnesso(true);
                    peer1.setIPDest("localhost");//peer1.setIPDest(peer2.getIndirizzoHost());
                    txtPeer1.Text = "Connesso!";
                }
                else
                {
                    peer1.setConnesso(false);
                    txtPeer1.Text = "Non connesso";
                }
                
            }


        }

        private void btnNC_Click(object sender, RoutedEventArgs e)
        {
            inviaPacchetto();
        }

        private void chkattendiRichiesta_Checked(object sender, RoutedEventArgs e)
        {
            riceviPacchetto();
        }

       
    }
}
