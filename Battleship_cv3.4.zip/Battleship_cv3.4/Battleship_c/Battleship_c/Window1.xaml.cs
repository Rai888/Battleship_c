﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        UdpClient client = new UdpClient(64445);
        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any, 0);
        peer peer1 = new peer();// peer 1
        peer peer2 = new peer();//peer 2
        static int turno = 0;
        List<string> naviPeer1;
        List<string> naviPeer2;
        static int punti1 = 0;
        static int punti2 = 0;


        SoundPlayer _soundtrack = new SoundPlayer("_bgsound.wav");
        

        /* ANCORA DA FARE
         * Creare una classe a parte che abbia le proprie navi(inizializzate a random)
         * 
         * invio del colpo 
         
         * Mittente:
		    string comando: H (colpo);
		    string coordinate: a-1 (colonna-riga);

         * metodo per vedere se la nave esiste sotto il bottone

             Destinatario:
		        string comando: RH (risposta colpo);
		        int risultato: -1 (mancato) / 0 (colpito) / 1 (affondato);
         */



        public Window1()
        {
            InitializeComponent();
            naviPeer1=Random();
            naviPeer2 = Random();
            naviPeer2 = add(naviPeer2);

            _soundtrack.Play();
        }

        
        private void hit(object sender, RoutedEventArgs e)
        {
            string coordinata = (sender as Button).Name,r;
            byte[] data = Encoding.ASCII.GetBytes("H;" + coordinata), dataReceived;
            string ip;
            if (turno%2==0 && (sender as Button).Name.Contains("Copy"))//se tocca al peer 1
            {
                txtTurno.Text = "PEER 2";
                ip = peer2.getIndirizzoHost();
                client.Send(data, data.Length, ip, 64445);
                dataReceived = client.Receive(ref riceveEP);
                r = Encoding.ASCII.GetString(dataReceived);
                textBox1.Text = coordinata;
                ricercaNave(sender);
            }
            else if (turno % 2 == 1 && !(sender as Button).Name.Contains("Copy"))//se tocca al peer 2
            {
                txtTurno.Text = "PEER 1";
                ip = peer1.getIndirizzoHost();
                client.Send(data, data.Length, ip, 64445);
                dataReceived = client.Receive(ref riceveEP);
                r = Encoding.ASCII.GetString(dataReceived);
                textBox.Text = coordinata;
                ricercaNave(sender);
            }

            
        }


        public List<string> Random() {  //per le navi 
            var n = new Random();
            byte[] j;
            int l1,n2;
            string temp="";
            List<string> v= new List<string>();
            for (int i = 0; i < 25; i++)
            {
                l1=n.Next(65,74);
                j=BitConverter.GetBytes(l1);  //una lettera a random da A a J

                n2 = n.Next(1, 10);
                temp = (Encoding.ASCII.GetString(j) + n2.ToString()).Remove(1,3);
                v.Add(temp);
            }
            Thread.Sleep(1000);
            return v;

        }


        public List<string> add(List<string> v) {
            string temp;
            List<string> l=new List<string>();
            for (int i = 0; i < v.Count; i++)
            {
                temp = v.ElementAt(i);
                temp += "_Copy";
                l.Add(temp);
            }

            return l;
        }


        private void ricercaNave(object sender) {
            Button btn = sender as Button;
            List<string> l = new List<string>();
            if (turno %2== 0)   
                l = naviPeer2;
            else
                l = naviPeer1;                          //prendo in considerazione la nave opposta dato che si sta attaccando
            for (int i = 0; i < l.Count; i++)
            {
                if (btn.Name == l.ElementAt(i))
                {
                    btn.IsEnabled = false;
                    btn.Content = "X";
                    if (turno % 2 == 0)
                    {
                        punti1++;
                        txtPunti1.Text = punti1.ToString();
                    }
                    else
                    {
                        punti2++;
                        txtPunti2.Text = punti2.ToString();
                    }
                        
                    break;
                }
                else
                {
                    btn.IsEnabled = false;
                    btn.Content = "-";
                }
            }
            turno++;
        }
    }
}
