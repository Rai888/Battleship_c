﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship_c
{
    class peer
    {
        private bool connesso;
        private string indirizzoIP;


        peer(string indirizzoIP) {
            this.connesso = false;
            this.indirizzoIP = indirizzoIP;
        }
    }
}
