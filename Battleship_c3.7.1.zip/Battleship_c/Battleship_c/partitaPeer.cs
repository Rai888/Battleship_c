﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Battleship_c
{
    class partitaPeer
    {
        public peer peer;
        private List<string> listNave;
        public int turno;

        public partitaPeer(peer peer, int turno) {
            this.peer = peer;
            this.listNave = Random();
            this.turno = turno;
        }


        
        private List<string> Random()
        {  //per le navi 
            var n = new Random();
            byte[] j;
            int l1, n2;
            string temp = "";
            List<string> v = new List<string>();
            for (int i = 0; i < 25; i++)
            {
                l1 = n.Next(65, 74);
                j = BitConverter.GetBytes(l1);  //una lettera a random da A a J

                n2 = n.Next(1, 10);
                temp = (Encoding.ASCII.GetString(j) + n2.ToString()).Remove(1, 3);
                v.Add(temp);
            }
            return v;

        }


        public int ricercaNave(string s, Window1 window)
        {
            int ris=-1;
            //-1(mancato) / 0(colpito) / 1(affondato)
            for (int i = 0; i < listNave.Count; i++)
            {
                if (s == listNave.ElementAt(i))
                {
                    ris=0;
                    //affondato(window, s);
                }
            }
            return ris;
        }

        private void affondato(Window1 window, string s) {
            /*a     b   c   d   e
             1      x       
             2      x          
             3      x         
             4              x   x
             5              
             */
            //considerando un colpito  sicuro
            //se sulla colonna successiva o sul numero successivo ci sono altre x allora return 1, ovvero affondata
            int n = Int32.Parse(s.Substring(1, 2));//3
            
            //A3

            int letteraAscii = (int)s[0];//65 = a
            char letteraSuccessiva = (char)++letteraAscii;
            
            Button b = (Button)window.FindName(letteraSuccessiva + n.ToString()); //b3
            Button c = (Button)window.FindName(s[0] + (++n).ToString());//a4

            if (b.Content=="X" || c.Content=="X" )
            {
                
            }
            




        }







    }
}
