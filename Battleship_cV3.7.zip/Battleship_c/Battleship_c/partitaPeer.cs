﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Battleship_c
{
    class partitaPeer
    {
        public peer peer;
        private List<string> listNave;
        public int turno;

        public partitaPeer(peer peer, int turno) {
            this.peer = peer;
            this.listNave = Random();
            this.turno = turno;
        }


        
        private List<string> Random()
        {  //per le navi 
            var n = new Random();
            byte[] j;
            int l1, n2;
            string temp = "";
            List<string> v = new List<string>();
            for (int i = 0; i < 25; i++)
            {
                l1 = n.Next(65, 74);
                j = BitConverter.GetBytes(l1);  //una lettera a random da A a J

                n2 = n.Next(1, 10);
                temp = (Encoding.ASCII.GetString(j) + n2.ToString()).Remove(1, 3);
                v.Add(temp);
            }
            return v;

        }


        public int ricercaNave(string s)
        {
            //-1(mancato) / 0(colpito) / 1(affondato)
            for (int i = 0; i < listNave.Count; i++)
            {
                if (s == listNave.ElementAt(i))
                {
                    return 0;
                }
            }
            return -1;
        }







    }
}
