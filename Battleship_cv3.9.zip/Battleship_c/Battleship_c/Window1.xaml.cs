﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public const int porta = 64445;
        UdpClient client = new UdpClient(porta);
        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any, 0);
        partitaPeer partitaPeer;
        public Window1(peer peer, int turno)
        {
            InitializeComponent();
            partitaPeer = new partitaPeer(peer, turno);
            if (turno % 2 == 1)
                attendoColpo();
        }

        private void hit(object sender, RoutedEventArgs e) {
            colpo(sender);
        }

        public void colpo(object sender){
            string coord; byte[] data;
            if (partitaPeer.turno % 2 == 0 && (sender as Button).Name.Contains("Copy"))	//se scelgo un bottone avversario 	
            {
                coord = (sender as Button).Name.Substring(0, 2); //A1
                data = Encoding.ASCII.GetBytes("H;" + coord);	//(H;A1)
                client.Send(data, data.Length, partitaPeer.peer.getIPDest(), porta);	//invia colpo con coordinate
                attendoRispostaAlColpo(sender as Button);                               //aspetta la risposta al proprio colpo

                partitaPeer.turno++;
                txtTurno.Text = "PEER 2";
                attendoColpo();
            }
            else
                MessageBox.Show("Non è il tuo turno!", "ATTENZIONE", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void attendoRispostaAlColpo(Button b) {
            byte[] dataReceived = client.Receive(ref riceveEP);//aspetto il pacchetto 
            string s = Encoding.ASCII.GetString(dataReceived); //(RH; 0)
            string[] v = s.Split(';');
            if (v[0]=="RH")
            {
                switch (v[1])
                {
                    case "-1":
                        b.IsEnabled = false;
                        b.Content = "-";
                        break;
                    case "0":
                        b.IsEnabled = false;
                        b.Content = "X";
                        break;
                    case "1":
                        b.IsEnabled = false;
                        b.Content = "X";
                        break;
                }
            }
        }



        private void attendoColpo() {
            byte[] dataReceived= client.Receive(ref riceveEP);	//il peer 2 aspetta il pacchetto
            string s= Encoding.ASCII.GetString(dataReceived);   // (H;A1)
            string[] v=s.Split(';');
            int ris=partitaPeer.ricercaNave(v[1], this);// 0 colpito -1 non è colpito 
            Button c = new Button();
            c = (Button)this.FindName(v[1]);
            c.IsEnabled = false;
            if (ris == 0)
                c.Content = "X";
            else if (ris == -1)
                c.Content = "-";
            else if (ris == 1)
                c.Content = "XX";
            byte[] data= Encoding.ASCII.GetBytes("RH;" + ris);   //invio se ha beccato la nave o meno
            client.Send(data, data.Length, partitaPeer.peer.getIPDest(), porta);
            txtTurno.Text = "PEER 1";	//avendo terminato tocca al peer 1
            partitaPeer.turno++;
        }
        
    }
}
