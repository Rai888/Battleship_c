﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace Battleship_c
{
    class partitaPeer
    {
        public peer peer;
        private List<string> listNave;
        public int turno;

        public partitaPeer(peer peer, int turno) {
            this.peer = peer;
            this.listNave = Random();
            this.turno = turno;
        }


        
        private List<string> Random()
        {  //per le navi 
            var n = new Random();
            byte[] j;
            int l1, n2;
            string temp = "";
            List<string> v = new List<string>();
            for (int i = 0; i < 50; i++)
            {
                l1 = n.Next(65, 74);
                j = BitConverter.GetBytes(l1);  //una lettera a random da A a J

                n2 = n.Next(1, 10);
                temp = (Encoding.ASCII.GetString(j) + n2.ToString()).Remove(1, 3);
                v.Add(temp);
            }
            return v;

        }


        public int ricercaNave(string s, Window1 window)
        {
            int ris=-1;
            //-1(mancato) / 0(colpito) / 1(affondato)
            for (int i = 0; i < listNave.Count; i++)
            {
                if (s == listNave.ElementAt(i))
                {
                    ris=0;
                    ris=affondato(window, s);
                }
            }
            return ris;
        }

        private int affondato(Window1 window, string s) {
            int n = int.Parse( s[1]+"\0");
            //s=D3 
            int ris;
            //destra
            char c = btnLettera(s[0], 0);
            string destr = c + n.ToString();   //E3
            //sinistra
            c = btnLettera(s[0], 1);
            string sinistr = c + n.ToString();//C3
            
            //giu
            string gi = s[0] + (++n).ToString();//D4
            --n;
            //su
            string suu = s[0] + (--n).ToString();//D2
            ++n;

            int pos = 0;

            if (listNave.Contains(gi)) pos = 1;
            else if (listNave.Contains(suu)) pos = 2;
            else if (listNave.Contains(destr)) pos = 3;
            else if (listNave.Contains(sinistr)) pos = 4;
            //devo fissare la direzione


            ris = mov(pos, s, window);

            if (pos == 1) pos = 2;
            else if (pos == 2) pos = 1;
            else if (pos == 3) pos = 4;
            else if (pos == 4) pos = 3;

            if(ris==1) ris = mov(pos, s, window);

            return ris;

        }

        private int mov(int pos,string s, Window1 window) {
            bool sent = false;
            string str = "";
            int n = int.Parse(s[1]+"\0"), ris;
            char c=s[0];
            Button b = new Button();
            do
            {   //seleziona il bottone in base a dove è stata fissata la direzione
                switch (pos)
                {
                    case 1:
                        str = s[0] + (++n).ToString();
                        b = (Button)window.FindName(str);
                        break;
                    case 2:
                        str = s[0] + (--n).ToString();
                        b = (Button)window.FindName(str);
                        break;
                    case 3:
                        c = btnLettera(c, 0);
                        str = c + n.ToString();
                        b = (Button)window.FindName(str);
                        break;
                    case 4:
                        c = btnLettera(c, 1);
                        str = c + n.ToString();
                        b = (Button)window.FindName(str);
                        break;
                }

                if (listNave.Contains(str))
                {
                    if ((string)b.Content == "X") { sent = true; ris = 1; }
                    else { sent = false; ris = 0; }
                }
                else { sent = false; ris = 1; }
            } while (sent);

            return ris;
        }


        private char btnLettera(char c, int i)
        {
            int letteraAscii = (int)c;//65 = a
            char letteraSuccessiva;
            if (i==0) letteraSuccessiva = (char)++letteraAscii;//c
            else
                letteraSuccessiva = (char)--letteraAscii;//a
            return letteraSuccessiva;
        }


    }
}
