﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Battleship_c
{
    public class peer
    {
        private bool connesso;
        private string IPHost;
        private string IPDest;


        public peer() {
            this.connesso = false;  //non ancora connesso
            this.IPHost = "localhost";
            this.IPDest = "";// ip destinatario successivamente 
        }

        public string getIPDest() {
            return IPDest;
        }

        public void setIPDest(string dest) {
            this.IPDest = dest;
        }

        public bool getConnesso() {
            return connesso;
        }

        public void setConnesso(bool connessione) {
            this.connesso = connessione;
        }

        public string getIndirizzoHost()
        {
            string HostName = Dns.GetHostName();
            IPAddress[] ipaddress = Dns.GetHostAddresses(HostName);
            return ipaddress[2].ToString();
        }

    }
}
