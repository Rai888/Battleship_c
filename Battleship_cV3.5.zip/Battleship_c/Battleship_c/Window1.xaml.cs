﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public const int porta = 64445;
        UdpClient client = new UdpClient(porta);
        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any, 0);
        static int turno = 0;
        static int punti1 = 0;
        static int punti2 = 0;
        partitaPeer partitaPeer;

        public Window1(peer peer)
        {
            InitializeComponent();
            partitaPeer = new partitaPeer(peer);
        }


        private void hit(object sender, RoutedEventArgs e) {
            string coord; byte[] data;
            if (turno % 2 == 0 && (sender as Button).Name.Contains("Copy"))
            {
                coord = (sender as Button).Name.Substring(0, 2);
                data= Encoding.ASCII.GetBytes("H;" + coord);
                client.Send(data, data.Length, partitaPeer.peer.getIPDest(), porta);
                attendoRispostaAlColpo(sender as Button);
            }
            turno++;
            txtTurno.Text = "PEER 2";
            attendoColpo();
        }

        private void attendoRispostaAlColpo(Button b) {
            byte[] dataReceived = client.Receive(ref riceveEP);
            string s = Encoding.ASCII.GetString(dataReceived); //(RH; 0)
            string[] v = s.Split(';');
            if (v[0]=="RH")
            {
                switch (v[1])
                {
                    case "-1":
                        b.IsEnabled = false;
                        b.Content = "-";
                        break;
                    case "0":
                        b.IsEnabled = false;
                        b.Content = "X";
                        break;
                    case "1":
                        break;
                }
            }
        }



        private void attendoColpo() {
            byte[] dataReceived= client.Receive(ref riceveEP);
            string s= Encoding.ASCII.GetString(dataReceived);   // (H;A1)
            string[] v=s.Split(';');
            int ris=partitaPeer.ricercaNave(v[1]);
            byte[] data= Encoding.ASCII.GetBytes("RH;" + ris);   //invio se ha beccato la nave o meno
            client.Send(data, data.Length, partitaPeer.peer.getIPDest(), porta);
            txtTurno.Text = "PEER 1";
            turno++;
        }




        


        
    }
}
