﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace Battleship_c
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        UdpClient client = new UdpClient(64444);
        IPEndPoint riceveEP = new IPEndPoint(IPAddress.Any, 0);
        peer peer = new peer();// peer 1
        SoundPlayer _start = new SoundPlayer("_start.wav");

        public MainWindow()
        {
            InitializeComponent();
            _start.Play();
        }

        

        private void inviaPacchetto() {
            if (!peer.getConnesso())
            {
                byte[] data = Encoding.ASCII.GetBytes("NC;" + "Denis1" + ";64444");    //richiesta di connessione NC=> Nuova Connessione    al posto di "localhost", peer2.getIndirizzoHost()
                client.Send(data, data.Length,txtIp.Text, 64444);  //ci andrà l'indirizzo ip dell'altro peer
                confermaPeer1();
            }
            else
                MessageBox.Show("Sei Già Connesso!");
            
        }


        private void riceviPacchetto() {
            byte[] dataReceived = client.Receive(ref riceveEP);     //ricevo la richiesta di connessione
            String risposta = Encoding.ASCII.GetString(dataReceived);//elaboro la risposta
            string ipDestinatario= riceveEP.Address.ToString();      //prendo l'ip del destinatario |   potevo prenderlo dal secondo campo della risposta
            string portaDestinatario=riceveEP.Port.ToString();       //prendo la porta del destinatario |   potevo prenderla dal terzo campo della risposta
            string comando=risposta.Substring(0, 2);                 //prendo il comando    

            byte[] risp;

            if (comando=="NC")  //se il comando è una richiesta di connessione
            {
                if (!peer.getConnesso())   //controllo che non sia connnesso il peer 
                {
                    txtPeer1.Text = "In corso...";
                    if (MessageBox.Show("Vuoi connetterti con l'Host?", "Seleziona", MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
                    {
                        accettaRichiestaConnessione(ipDestinatario);    // mi passo l'ip del destinatario con cui instauro una connessione
                        risp = Encoding.ASCII.GetBytes("RC;true;" + "Denis2");          // pacchetto per il destinatario-accetta connessione      va messo al posto dell'ipDestinatario, l'ip del secondo peer
                        client.Send(risp, risp.Length, ipDestinatario, 64444);
                        Window2 game = new Window2(peer,1);
                        game.Show();
                    }
                    else
                    {
                        risp = Encoding.ASCII.GetBytes("RC;false;" + "Denis2");   //pacchetto per il destinatario-rifiuto connessione
                        client.Send(risp, risp.Length, ipDestinatario, 64444);
                    }
                }
                else
                    MessageBox.Show("L'host è già connesso!");
            }
           
        }


        private void accettaRichiestaConnessione(string ipdest) {
            peer.setConnesso(true);
            peer.setIPDest(ipdest);
            txtPeer1.Text = "Connesso!";
        }


        private void confermaPeer1() {
            byte[] data = client.Receive(ref riceveEP);
            string ip=riceveEP.Address.ToString();
            string comando = Encoding.ASCII.GetString(data).Substring(0, 2);
            string porta=riceveEP.Port.ToString();
            string[] v=Encoding.ASCII.GetString(data).Split(';');



            if (v[0]== "RC")
            {
                if (v[1]=="true")
                {
                    peer.setConnesso(true);
                    peer.setIPDest(txtIp.Text);//txtPeer.Text
                    txtPeer1.Text = "Connesso!";
                    Window2 game = new Window2(peer,0);
                    game.Show();
                }
                else
                {
                    peer.setConnesso(false);
                    txtPeer1.Text = "Non connesso";
                }
                
            }

        }

        private void btnNC_Click(object sender, RoutedEventArgs e)
        {
            inviaPacchetto();
        }

        private void chkattendiRichiesta_Checked(object sender, RoutedEventArgs e)
        {
            riceviPacchetto();
        }

        private void btnAzzera_Click(object sender, RoutedEventArgs e)
        {
            txtPeer1.Text = "Non connesso";
            peer.setConnesso(false);
            peer.setIPDest("");
            chkattendiRichiesta.IsChecked = false;
        }
    }
}
